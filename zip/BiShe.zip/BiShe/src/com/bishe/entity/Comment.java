package com.bishe.entity;

public class Comment {

}
