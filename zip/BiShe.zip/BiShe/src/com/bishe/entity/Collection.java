package com.bishe.entity;

public class Collection {

}
