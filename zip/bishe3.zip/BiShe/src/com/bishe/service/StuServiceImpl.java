package com.bishe.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bishe.dao.StuDaoImpl;
import com.bishe.entity.Student;


@Service
@Transactional(readOnly=false)
public class StuServiceImpl {

	@Resource
	private StuDaoImpl stuDaoImpl;
	
	/**
	 * @desc 通过id查询学生
	 * @param 原源
	 * @createDate 2019年2月13日
	 * @return List
	 * @throws Exception
	 */
	public Student findById(int stuId) throws Exception{
		return stuDaoImpl.findById(stuId);		
	}
	
	/**
	 * @desc 通过id查询学生所考数学种类
	 * @param 原源
	 * @createDate 2019年2月13日
	 * @return List
	 * @throws Exception
	 */
	public int findMathById(int stuId) throws Exception{
		return stuDaoImpl.findMathById(stuId);	
	}
	
	/**
	 * @desc 通过id查询学生所考英语种类
	 * @param 原源
	 * @createDate 2019年2月13日
	 * @return List
	 * @throws Exception
	 */
	public int findEnglishById(int stuId) throws Exception{
		return stuDaoImpl.findEnglishById(stuId);	
	}
}
