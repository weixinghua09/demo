package com.bishe.dao;


import javax.annotation.Resource;

import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.bishe.entity.Student;
import com.bishe.dao.BaseDao;

@Repository
public class StuDaoImpl extends BaseDao<Student>{
	@Resource
	private SessionFactory sessionFactory;
	

		/**
		 * 添加用户角色项
		 * @param urr
		 * @return
		 * @throws Exception
		 */
		public int saveStu(Student stu)throws Exception {
			SessionFactory sessionFactory = super.getSessionFactory();
			sessionFactory.getCurrentSession().save(stu);
			
			return stu.getstuId();
			
		}
		
		/**
		 * @desc 通过id查询学生
		 * @param 原源
		 * @createDate 2019年2月13日
		 * @return List
		 * @throws Exception
		 */
		public Student findById(int stuId) throws Exception{
			return this.get(stuId);
		}
		
		/**
		 * @desc 通过id查询学生所考数学种类
		 * @param 原源
		 * @createDate 2019年2月13日
		 * @return List
		 * @throws Exception
		 */
		public int findMathById(int stuId) throws Exception{
			return this.get(stuId).getMath();
		}
		
		/**
		 * @desc 通过id查询学生所考英语种类
		 * @param 原源
		 * @createDate 2019年2月13日
		 * @return List
		 * @throws Exception
		 */
		public int findEnglishById(int stuId) throws Exception{
			return this.get(stuId).getEnglish();
		}

}
