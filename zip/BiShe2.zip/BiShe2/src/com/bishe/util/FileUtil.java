package com.bishe.util;

public class FileUtil {
	
	public static final String fileUploadPath = "F://upload";

}
