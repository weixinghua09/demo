package com.bishe.entity;

public class Article {

}
